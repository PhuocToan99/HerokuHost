export class Score {
    id: string;
    examId: string;
    accountId: string;
    points: number;
}