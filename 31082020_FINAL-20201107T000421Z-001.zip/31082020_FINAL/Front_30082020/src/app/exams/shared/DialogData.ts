export interface DialogData {
    Name : string;
  }