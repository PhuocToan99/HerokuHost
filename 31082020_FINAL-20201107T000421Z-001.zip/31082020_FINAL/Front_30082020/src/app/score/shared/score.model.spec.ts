import {Score} from './score.model';

describe('Score',() => {
    it('should create an instance', () => {
        expect(new Score()).toBeTruthy();
    });
});