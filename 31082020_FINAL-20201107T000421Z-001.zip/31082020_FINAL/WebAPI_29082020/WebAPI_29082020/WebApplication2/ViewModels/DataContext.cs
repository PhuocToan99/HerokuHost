﻿namespace WebApplication2.ViewModels
{
    public class DataContext
    {
    }
}