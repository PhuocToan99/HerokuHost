﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.ViewModels
{
    public class ExamRating
    {
        public int Rating { get; set; }
        public int Total { get; set; }
    }
}
