export class QuestionPool{
    Id: number;
    Name: string;
    CreatedDate : Date;
    Description : string;
    AccountId :number;
    ParentPoolId :number;
}
