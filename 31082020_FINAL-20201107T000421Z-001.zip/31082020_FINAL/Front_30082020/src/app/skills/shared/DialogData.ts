export interface DialogData {
    Id : string;
    Name : string;
    Description :string;
    Image : File;
    Ratings : number;
  }