export class QuestionChoice{
    id:number;
    choice:string;
    isCorrect:boolean;
    questionId:number;
}