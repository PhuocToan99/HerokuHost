export class ArrayPartName{
    id:number;
    name:number;
    idquestion:string;
}





