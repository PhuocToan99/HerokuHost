export class questionpoolDBmodel {
    Id: number;
    Name: string;
}