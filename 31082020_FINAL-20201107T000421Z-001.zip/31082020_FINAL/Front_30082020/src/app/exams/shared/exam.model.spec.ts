import { Exam } from './exam.model';

describe('Exam', () => {
  it('should create an instance', () => {
    expect(new Exam()).toBeTruthy();
  });
});