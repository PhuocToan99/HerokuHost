export interface DialogData {
    Name : boolean;
}