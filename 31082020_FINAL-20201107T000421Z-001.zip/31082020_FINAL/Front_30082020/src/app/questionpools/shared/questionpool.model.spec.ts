import { QuestionPool } from './questionpool.model';
describe('QuestionPool', () => {
    it('should create an instance', () => {
      expect(new QuestionPool()).toBeTruthy();
    });
  });