export class skillDBmodel {
    Id: string;
    Name: string;
}