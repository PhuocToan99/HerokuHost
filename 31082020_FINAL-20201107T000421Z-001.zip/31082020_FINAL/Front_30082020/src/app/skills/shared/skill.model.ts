export class Skill {
    Id : string;
    Name : string;
    Description :string;
    Image : File;
}